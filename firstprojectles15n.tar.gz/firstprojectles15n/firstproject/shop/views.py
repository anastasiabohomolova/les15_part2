from django.contrib import messages
from django.contrib.auth.decorators import permission_required, user_passes_test
from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, HttpResponseRedirect, Http404
from shop.models import Shoping
from shop.forms import ShopingForm
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage


def shop_page(request):
    queryset = Shoping.objects.all()
    paginator = Paginator(queryset, 3)
    page_request_var = 'page'
    page = request.GET.get(page_request_var)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        queryset = paginator.page(1)
    except EmptyPage:
        queryset = paginator.page(paginator.num_pages)

    context = {
        'title': 'Shop',
        'objects_list': queryset,
        'page_request_var': page_request_var
    }

    return render(request, 'home.html', context)

def detail_page(request, id=None):
    instance = get_object_or_404(Shoping, id=id)
    context = {
        'title': 'Detail',
        'object': instance
    }

    return render(request, 'detail_page.html', context)

def page_category(request):
    return render(request, 'category_page.html')

def page_dresses(request):
    queryset = Shoping.objects.filter(type="dresses")
    context = {
        'title': 'Dresses',
        'objects_closes': queryset
    }

    return render(request, 'obj_closes.html', context)

def page_bags(request):
    queryset = Shoping.objects.filter(type="bags")
    context = {
        'title': 'Bags',
        'objects_closes': queryset
    }

    return render(request, 'obj_closes.html', context)

def page_suits(request):
    queryset = Shoping.objects.filter(type="suits")
    context = {
        'title': 'Suits',
        'objects_closes': queryset
    }

    return render(request, 'obj_closes.html', context)


def create_closes(request):
    if 'Катя' in request.user.first_name or request.user.is_superuser:
        form = ShopingForm(request.POST or None,
                        request.FILES or None)
        if form.is_valid():
            instance = form.save(commit=False)
            instance.save()
            image_url = instance.get_image()
            messages.success(request, f'<a href="{image_url}">Closes</a> created!', extra_tags='html_safe')
            return HttpResponseRedirect(instance.get_url_category())
        context = {
            'title': 'Create closes',
            'form': form
        }
        return render(request, 'create_closes.html', context)
    else:
        raise Http404


def update_closes(request, id=None):
    if 'Дмитро' in request.user.first_name or request.user.is_superuser:
        instance = get_object_or_404(Shoping, id=id)
        form = ShopingForm(request.POST or None,
                        request.FILES or None,
                        instance=instance)
        if form.is_valid():
            instance = form.save(commit=False)

            instance.save()
            messages.success(request, '<a href="/shop/create/">Closes</a> update!', extra_tags='html_safe')
            return HttpResponseRedirect(instance.get_url_category())

        context = {
            'title': 'Update closes',
            'form': form
        }

        return render(request, 'create_closes.html', context)
    else:
        raise Http404

def delete_closes(request, id=None):
    if 'Олег' in request.user.first_name or request.user.is_superuser:
        instance = get_object_or_404(Shoping, id=id)
        instance.user = request.user
        instance.delete()
        return redirect('shop:shop_page')
    else:
        raise Http404

def page_image(request, id=None):
    instance = get_object_or_404(Shoping, id=id)
    context = {
        'title': 'Detail',
        'object': instance
    }

    return render(request, 'image.html', context)











